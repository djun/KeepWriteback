#!/bin/sh

i=1
MEMBASELINE=1228  # 下限：1.2G
let SMALLDELAY=60  # 默认检测间隔
let BIGDELAY=240  # 默认大检测间隔
let delay=${SMALLDELAY}

		echo "开机优化运行中..."
		echo all > /sys/block/zram0/idle
		sleep 60
		writeback "idle"
		echo "执行完成！"
		echo "----------------------------------------------------"

writeback(){
		while [ true ]; do
				
		CHECKSCREENOFF=`dumpsys window policy | grep "screenState"`
		ISSCREENOFF=$(echo ${CHECKSCREENOFF} | grep "SCREEN_STATE_OFF")
  
		if [[ "${ISSCREENOFF}" == "" ]]; then
			echo "进入了亮屏！写入${1}！"
			echo ${1} > /sys/block/zram0/writeback
			sleep ${delay}
			let 'i+=1'
		fi
		break
	done
}

while [ true ]; do	

		CATMEMFREE=`cat /proc/meminfo | grep "MemFree:" | sed -r "s/MemFree: +([0-9]+) kB/\1/g"`
        MEMFREE=$(echo ${CATMEMFREE})
        CATMEMCACHED=`cat /proc/meminfo | grep "Cached:" | sed -n "1p" | sed -r "s/Cached: +([0-9]+) kB/\1/g"`
      MEMCACHED=$(echo ${CATMEMCACHED})
  let MEMLEFT=${MEMFREE}+${MEMCACHED}
  let MEMLEFT=${MEMLEFT}/1024
  
	echo "----------------------------------------------------"
	echo "共${i}次运行"
	echo "开始时间为:" `date "+%Y-%m-%d %H:%M:%S"`
	ORIGINADATA=$(cat /sys/block/zram0/bd_stat)
	OLDSIZE=$(echo ${ORIGINADATA} | awk '{print $1}')
	((TIMES=$i %50))
	
	   if [ ${MEMLEFT} -lt MEMBASELINE -o "$TIMES" == 0 ]; then
   echo "--------"
   echo "--内存不足或达到设定时间，强制回收中! 写入idle! "
   echo all > /sys/block/zram0/idle
		writeback "idle"
		let delay=${BIGDELAY}
		let 'i+=1'
	else
		writeback "huge"
		let delay=${SMALLDELAY}
	fi
	
	NEWDATA=$(cat /sys/block/zram0/bd_stat)
	NEWSIZE=$(echo ${NEWDATA} | awk '{print $1}')
	READ=$(echo ${NEWDATA} | awk '{print $2}')
	WRITE=$(echo ${NEWDATA} | awk '{print $3}')

	let OLDSIZE=${OLDSIZE}*4/1024
	let NEWSIZE=${NEWSIZE}*4/1024
	let DIFFSIZE=${NEWSIZE}-${OLDSIZE}
	let READ=${READ}*4/1024
	let WRITE=${WRITE}*4/1024
	echo "结束时间为:" `date "+%Y-%m-%d %H:%M:%S"`
	echo "原写回大小为：${OLDSIZE}MB, 新大小为：${NEWSIZE}MB, 相差${DIFFSIZE}MB"
	echo "总读取为：${READ}MB, 总写入为：${WRITE}MB"
	echo "----------------------------------------------------"
	sleep 180
done
