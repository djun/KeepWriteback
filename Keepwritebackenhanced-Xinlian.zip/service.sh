#!/system/bin/sh

MODDIR=${0%/*}

sleep 5m
chmod +x $MODDIR/keepwriteback.sh
$MODDIR/keepwriteback.sh > /cache/writeback.log 2>&1 &