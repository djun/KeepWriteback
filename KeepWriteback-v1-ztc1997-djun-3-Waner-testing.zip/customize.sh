SKIPUNZIP=0
ASH_STANDALONE=0
set_perm_recursive $MODPATH 0 0 0755 0644


dd if=/dev/zero of=/data/zramwriteback bs=1M count=3072
losetup /dev/block/loop0 /data/zramwriteback
echo /dev/block/loop0 > /sys/block/zram0/backing_dev