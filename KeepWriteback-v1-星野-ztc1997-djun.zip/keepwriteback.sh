#!/bin/sh

let DEFAULTDELAY=10
let DEFAULTLARGEDELAY=180
let DEFAULTTIMESLIMIT=60

# 检测间隔调整为 10秒
let delay=${DEFAULTDELAY}
# 计次上限设定为 60次
let times_limit=${DEFAULTTIMESLIMIT}

writeback(){
 ORIGINADATA=$(cat /sys/block/zram0/bd_stat)
 OLDSIZE=$(echo ${ORIGINADATA} | awk '{print $1}')
 
 echo "--------"
 echo "[${i}] 息屏检测开始: " `date "+%Y-%m-%d %H:%M:%S"`
 
 j=0
 while [ true ]; do
  let 'j+=1'
  
  # 检查息屏，息屏时触发参数指定操作
  CHECKSCREENON=`dumpsys window policy | grep "screenState"`
  ISSCREENON=$(echo ${CHECKSCREENON} | grep "SCREEN_STATE_ON")
  if [ "${ISSCREENON}" == "" -o ${j} -ge ${times_limit} ]; then
  # 增加判断条件：计数超过 N次
   echo "--------"
   echo "--[${j}] 息屏或超时! 写入${1}! 时间: " `date "+%Y-%m-%d %H:%M:%S"`
   #息屏
   echo ${1} > /sys/block/zram0/writeback
   break
  fi
  
  sleep ${delay}
 done

 NEWDATA=$(cat /sys/block/zram0/bd_stat)
 NEWSIZE=$(echo ${NEWDATA} | awk '{print $1}')
 READ=$(echo ${NEWDATA} | awk '{print $2}')
 WRITE=$(echo ${NEWDATA} | awk '{print $3}')

 let OLDSIZE=${OLDSIZE}*4/1024
 let NEWSIZE=${NEWSIZE}*4/1024
 let DIFFSIZE=${NEWSIZE}-${OLDSIZE}

 let READ=${READ}*4/1024
 let WRITE=${WRITE}*4/1024
 echo "原写回: ${OLDSIZE}MB, 新大小：${NEWSIZE}MB, 相差${DIFFSIZE}MB; 总读取: ${READ}MB, 总写入: ${WRITE}MB"
}


echo "生效: " `date "+%Y-%m-%d %H:%M:%S"`
echo all > /sys/block/zram0/idle


{
 while [ true ]; do
  # 剩余内存低于阈值时，触发huge操作
  CATMEMFREE=`cat /proc/meminfo | grep "MemFree:" | sed -r "s/MemFree: +([0-9]+) kB/\1/g"`
  MEMFREE=$(echo ${CATMEMFREE})
  #echo ${MEMFREE}
  CATMEMCACHED=`cat /proc/meminfo | grep "Cached:" | sed -n "1p" | sed -r "s/Cached: +([0-9]+) kB/\1/g"`
  MEMCACHED=$(echo ${CATMEMCACHED})
  #echo ${MEMCACHED}
  let MEMLEFT=${MEMFREE}+${MEMCACHED}
  let MEMLEFT=${MEMLEFT}/1024
  let MEMBASELINE=2048  # 下限：2.0GB
  #echo ${MEMLEFT},${MEMBASELINE}
  if [ ${MEMLEFT} -lt MEMBASELINE ]; then
   echo "--------"
   echo "--内存剩余触及下限! 剩余${MEMLEFT}MB, 阈值${MEMBASELINE}MB, 写入huge! 时间: " `date "+%Y-%m-%d %H:%M:%S"`
   echo "huge" > /sys/block/zram0/writeback
   # 写huge时，临时增大delay
   let delay=${DEFAULTLARGEDELAY}
  fi
  
  sleep ${delay}
  # 恢复默认delay
  let delay=${DEFAULTDELAY}
 done
} >> /cache/writeback.log 2>&1 &


i=0
while [ true ]; do
 let 'i+=1'

 writeback "idle"
 echo all > /sys/block/zram0/idle

 # 每 11 分钟 写回一次（idle）
 sleep 11m
done

wait
date
