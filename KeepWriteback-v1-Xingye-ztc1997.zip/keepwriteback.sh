#!/bin/sh

writeback(){
 ORIGINADATA=$(cat /sys/block/zram0/bd_stat)
 OLDSIZE=$(echo ${ORIGINADATA} | awk '{print $1}')

 j=0
 while [ true ]; do
  let 'j+=1'
  CHECKSCREENON=`dumpsys window policy | grep "screenState"`
  ISSCREENON=$(echo ${CHECKSCREENON} | grep "SCREEN_STATE_ON")
  if [[ "${ISSCREENON}" == "" ]]; then
   echo "第${j}次终于进入了息屏！写入${1}！"
   #息屏
   echo ${1} > /sys/block/zram0/writeback
   break
  fi
  sleep 60
 done

 NEWDATA=$(cat /sys/block/zram0/bd_stat)
 NEWSIZE=$(echo ${NEWDATA} | awk '{print $1}')
 READ=$(echo ${NEWDATA} | awk '{print $2}')
 WRITE=$(echo ${NEWDATA} | awk '{print $3}')

 let OLDSIZE=${OLDSIZE}*4/1024
 let NEWSIZE=${NEWSIZE}*4/1024
 let DIFFSIZE=${NEWSIZE}-${OLDSIZE}

 let READ=${READ}*4/1024
 let WRITE=${WRITE}*4/1024
 echo "结束时间为:" `date "+%Y-%m-%d %H:%M:%S"`
 echo "原写回大小为：${OLDSIZE}MB, 新大小为：${NEWSIZE}MB, 相差${DIFFSIZE}MB"
 echo "总读取为：${READ}MB, 总写入为：${WRITE}MB"
 echo "----------------------------------------------------"
}


echo all > /sys/block/zram0/idle
# 首次回写等待 150 分钟
sleep 150m

i=0
while [ true ]; do
 let 'i+=1'
 echo "----------------------------------------------------"
 echo "第${i}次运行.."
 echo "开始时间为:" `date "+%Y-%m-%d %H:%M:%S"`

 writeback "idle"
 echo all > /sys/block/zram0/idle

 # 之后每 24 小时回写一次
 sleep 24h
done